// Presentational-only loading placeholders. No data fetching or
// state logic lives here — Home.jsx and Details.jsx decide when to
// render these based on their existing `loading` state.

export function ShowCardSkeleton() {
  return (
    <div className="skeleton-card" aria-hidden="true">
      <div className="skeleton skeleton-poster" />
      <div className="skeleton skeleton-line" />
      <div className="skeleton skeleton-line short" />
    </div>
  );
}

export function ShowGridSkeleton({ count = 8 }) {
  return (
    <div className="shows-grid" role="status" aria-label="Loading shows">
      {Array.from({ length: count }).map((_, index) => (
        <ShowCardSkeleton key={index} />
      ))}
    </div>
  );
}

export function DetailsSkeleton() {
  return (
    <div className="details-skeleton" role="status" aria-label="Loading show details">
      <div className="skeleton skeleton-line short" style={{ width: 120, height: 14 }} />
      <div className="details-content" style={{ marginTop: 24 }}>
        <div className="skeleton skeleton-poster-lg" />
        <div>
          <div className="skeleton skeleton-line" style={{ width: "70%", height: 32 }} />
          <div className="skeleton skeleton-line" style={{ width: "40%" }} />
          <div className="skeleton skeleton-line" style={{ width: "55%" }} />
          <div className="skeleton skeleton-line" style={{ width: "35%" }} />
          <div className="skeleton skeleton-line" style={{ width: 160, height: 40, marginTop: 16 }} />
        </div>
      </div>
    </div>
  );
}
