import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { useWatchlist } from "../context/WatchlistContext";
import { DetailsSkeleton } from "../components/Skeletons";
import { getEpisodes } from "../services/api";
import "../Details.css"

function Details() {
  const {
      addToWatchlist,
      removeFromWatchlist,
      isInWatchlist,
  } = useWatchlist();
  const { id } = useParams();

  const [show, setShow] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [retryCount, setRetryCount] = useState(0)

  const [episodes, setEpisodes] = useState([]);
  const [episodesLoading, setEpisodesLoading] = useState(true);
  const [episodesError, setEpisodesError] = useState("");
  const [openSeason, setOpenSeason] = useState(null);

  useEffect(() => {
    let ignore = false

    const fetchDetails = async ()=>{
      try{
        setLoading(true)
        setError("")
        const response = await fetch(`https://api.tvmaze.com/shows/${id}?embed=cast`)
        if(!response.ok) throw new Error("Failed to fetch show details");
        const data = await response.json()
        if(!ignore) setShow(data)
      } catch(err){
        console.error(err)
        if(!ignore) setError("Failed to load details")
      } finally {
        if(!ignore) setLoading(false)
      }
    }
    fetchDetails();
    return ()=> {ignore = true}
  }, [id, retryCount]);

  useEffect(() => {
    let ignore = false;

    const fetchEpisodes = async () => {
      try {
        setEpisodesLoading(true);
        setEpisodesError("");
        const data = await getEpisodes(id);
        if (!ignore) {
          setEpisodes(data);
          const seasons = [...new Set(data.map((ep) => ep.season))];
          setOpenSeason(seasons.length ? seasons[0] : null);
        }
      } catch (err) {
        console.error(err);
        if (!ignore) setEpisodesError("Failed to load episodes");
      } finally {
        if (!ignore) setEpisodesLoading(false);
      }
    };

    fetchEpisodes();
    return () => { ignore = true };
  }, [id, retryCount]);

  if (loading) {
    return <DetailsSkeleton />;
  }

  if (error) {
    return (
      <div className="details-error">
        <div className="error-icon" aria-hidden="true">⚠️</div>
        <p>{error}</p>
        <button onClick={()=> setRetryCount((c) => c+1)}>Try Again</button>
      </div>
    );
  }

  if (!show) {
    return <p className="details-loading-text">Show not found.</p>;
  }

  const cast = show._embedded?.cast || []
  const inWatchlist = isInWatchlist(show.id);

  const episodesBySeason = episodes.reduce((acc, ep) => {
    if (!acc[ep.season]) acc[ep.season] = [];
    acc[ep.season].push(ep);
    return acc;
  }, {});
  const seasonNumbers = Object.keys(episodesBySeason)
    .map(Number)
    .sort((a, b) => a - b);

  return (
    <div className="details-page">
      <Link to="/" className="details-back-link">← Back to Home</Link>

      <div className="details-content">
        <div className="details-poster-frame">
          <img
            className="details-poster"
            src={
              show.image?.original ||
              show.image?.medium ||
              "https://via.placeholder.com/300x450"
            }
            alt={show.name}
          />
        </div>

        <div className="details-info">
          <h1>{show.name}</h1>

          <div className="details-meta">
            <span className="rating-chip">⭐ {show.rating?.average || "N/A"}</span>
            <span>📺 {show.network?.name || "N/A"}</span>
            <span>📅 {show.premiered || "N/A"}</span>
            <span>📌 {show.status || "N/A"}</span>
          </div>

          <p>
            🎭 Genres:{" "}
            {show.genres?.length
              ? show.genres.join(", ")
              : "No genres available"}
          </p>

          <a
            href={`https://www.youtube.com/results?search_query=${encodeURIComponent(show.name + "trailer")}`}
            target="_blank"
            rel="noopener noreferrer"
            className="trailer-link"
          >
             ▶ Search Trailer on YouTube
          </a>

          <button
            className={`watchlist-toggle-btn${inWatchlist ? " in-watchlist" : ""}`}
            onClick={() => {
              if (inWatchlist) {
                removeFromWatchlist(show.id);
              } else {
                addToWatchlist(show);
              }
            }}
          >
            {inWatchlist ? "✓ Remove from Watchlist" : "+ Add to Watchlist"}
          </button>

          <h2>Synopsis</h2>

          <div
            className="details-summary"
            dangerouslySetInnerHTML={{
              __html: show.summary || "No summary available.",
            }}
          />
        </div>
      </div>

      <div className="cast-section">
        <h2>Cast</h2>

        <div className="cast-grid">
          {cast.length === 0 && <p>No cast information available.</p>}
          {cast.map((member) => (
            <div className="cast-card" key={member.person.id}>
              <img
                src={
                  member.person.image?.medium ||
                  "https://via.placeholder.com/100x100"
                }
                alt={member.person.name}
              />

              <h3>{member.person.name}</h3>
              <p>as {member.character.name}</p>
            </div>
          ))}
        </div>
      </div>

      <div className="episodes-section">
        <h2>Episodes</h2>

        {episodesLoading && (
          <p className="episodes-status">Loading episodes…</p>
        )}

        {!episodesLoading && episodesError && (
          <div className="episodes-error">
            <p>{episodesError}</p>
            <button onClick={() => setRetryCount((c) => c + 1)}>Try Again</button>
          </div>
        )}

        {!episodesLoading && !episodesError && seasonNumbers.length === 0 && (
          <p className="episodes-status">No episode information available.</p>
        )}

        {!episodesLoading && !episodesError && seasonNumbers.length > 0 && (
          <div className="seasons-list">
            {seasonNumbers.map((seasonNum) => {
              const isOpen = openSeason === seasonNum;
              return (
                <div className="season-block" key={seasonNum}>
                  <button
                    className="season-toggle"
                    onClick={() => setOpenSeason(isOpen ? null : seasonNum)}
                    aria-expanded={isOpen}
                  >
                    <span>Season {seasonNum}</span>
                    <span className="season-count">
                      {episodesBySeason[seasonNum].length} episodes
                    </span>
                    <span className="season-caret">{isOpen ? "▾" : "▸"}</span>
                  </button>

                  {isOpen && (
                    <ul className="episode-list">
                      {episodesBySeason[seasonNum].map((ep) => (
                        <li className="episode-item" key={ep.id}>
                          <span className="episode-number">
                            S{String(ep.season).padStart(2, "0")}E
                            {String(ep.number).padStart(2, "0")}
                          </span>
                          <span className="episode-name">{ep.name}</span>
                          {ep.airdate && (
                            <span className="episode-airdate">{ep.airdate}</span>
                          )}
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

export default Details;
