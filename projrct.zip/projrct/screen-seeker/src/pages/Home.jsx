import { useEffect, useState, useMemo, useRef } from "react";
import { getShows, searchShows } from "../services/api";
import ShowCard from "../components/ShowCard";
import { ShowGridSkeleton } from "../components/Skeletons";
import ErrorState from "../components/ErrorState";

function Home() {
  const [shows, setShows] = useState([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [genreFilter, setGenreFilter] = useState("All");
  const [sortBy, setSortBy] = useState("none");
  const [currentPage, setCurrentPage] = useState(1);
  const SHOWS_PER_PAGE = 20;

  // Debounce ref — holds the timeout id so we can cancel it
  const debounceRef = useRef(null);

  const fetchShows = async () => {
    try {
      setLoading(true);
      setError("");
      const data = await getShows();
      setShows(data);
    } catch (err) {
      console.error(err);
      setError("Failed to load shows.");
    } finally {
      setLoading(false);
    }
  };

  const runSearch = async (query) => {
    if (!query.trim()) {
      fetchShows();
      return;
    }
    try {
      setLoading(true);
      setError("");
      const data = await searchShows(query);
      setShows(data);
    } catch (err) {
      console.error(err);
      setError("Failed to search shows.");
    } finally {
      setLoading(false);
    }
  };

  // Debounced search — fires 400ms after the user stops typing
  const handleSearchChange = (event) => {
    const value = event.target.value;
    setSearch(value);

    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => {
      runSearch(value);
    }, 400);
  };

  // Keep submit working too (for accessibility / Enter key)
  const handleSearch = (event) => {
    event.preventDefault();
    if (debounceRef.current) clearTimeout(debounceRef.current);
    runSearch(search);
  };

  useEffect(() => {
    // Initial data fetch on mount — intentionally calls setState inside the
    // effect since this is the standard "fetch on mount" pattern.
    // eslint-disable-next-line react-hooks/set-state-in-effect
    fetchShows();
    // Cleanup debounce on unmount
    return () => {
      if (debounceRef.current) clearTimeout(debounceRef.current);
    };
  }, []);

  const genres = useMemo(() => {
    const genreSet = new Set();
    shows.forEach((show) => {
      show.genres?.forEach((g) => genreSet.add(g));
    });
    return ["All", ...Array.from(genreSet).sort()];
  }, [shows]);

  const visibleShows = useMemo(() => {
    let result = shows;

    if (genreFilter !== "All") {
      result = result.filter((show) => show.genres?.includes(genreFilter));
    }

    if (sortBy === "rating-desc") {
      result = [...result].sort(
        (a, b) => (b.rating?.average || 0) - (a.rating?.average || 0)
      );
    } else if (sortBy === "rating-asc") {
      result = [...result].sort(
        (a, b) => (a.rating?.average || 0) - (b.rating?.average || 0)
      );
    }

    return result;
  }, [shows, genreFilter, sortBy]);

  const totalPages = Math.max(
    1,
    Math.ceil(visibleShows.length / SHOWS_PER_PAGE)
  );

  const paginatedShows = useMemo(() => {
    const start = (currentPage - 1) * SHOWS_PER_PAGE;
    return visibleShows.slice(start, start + SHOWS_PER_PAGE);
  }, [visibleShows, currentPage]);

  useEffect(() => {
    // Reset to page 1 whenever the filtered/sorted result set changes.
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setCurrentPage(1);
  }, [genreFilter, sortBy, shows]);

  const goToPage = (page) => {
    const safePage = Math.min(Math.max(page, 1), totalPages);
    setCurrentPage(safePage);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <div>
      <div className="home-hero">
        <h1>ScreenSeeker</h1>
        <p className="tagline">Discover Movies & TV Shows</p>

        <form onSubmit={handleSearch} className="search-form">
          <label htmlFor="show-search" className="visually-hidden">
            Search for a show
          </label>
          <input
            id="show-search"
            type="text"
            placeholder="Search for a show..."
            value={search}
            onChange={handleSearchChange}
          />
          <button type="submit">Search</button>
        </form>

        <div className="filter-bar">
          <label htmlFor="genre-filter">
            Genre:{" "}
            <select
              id="genre-filter"
              value={genreFilter}
              onChange={(event) => setGenreFilter(event.target.value)}
            >
              {genres.map((g) => (
                <option key={g} value={g}>
                  {g}
                </option>
              ))}
            </select>
          </label>

          <label htmlFor="sort-by">
            Sort by rating:{" "}
            <select
              id="sort-by"
              value={sortBy}
              onChange={(event) => setSortBy(event.target.value)}
            >
              <option value="none">None</option>
              <option value="rating-desc">Highest first</option>
              <option value="rating-asc">Lowest first</option>
            </select>
          </label>
        </div>
      </div>

      {loading ? (
        <ShowGridSkeleton count={SHOWS_PER_PAGE} />
      ) : error ? (
        <ErrorState message={error} onRetry={fetchShows} />
      ) : visibleShows.length === 0 ? (
        <p className="no-results">
          No titles found matching your search.
        </p>
      ) : (
        <>
          <div className="shows-grid">
            {paginatedShows.map((show) => (
              <ShowCard key={show.id} show={show} />
            ))}
          </div>

          {totalPages > 1 && (
            <div className="pagination">
              <button
                onClick={() => goToPage(currentPage - 1)}
                disabled={currentPage === 1}
                className="pagination-btn"
              >
                ← Prev
              </button>

              <span className="pagination-info">
                Page {currentPage} of {totalPages}
              </span>

              <button
                onClick={() => goToPage(currentPage + 1)}
                disabled={currentPage === totalPages}
                className="pagination-btn"
              >
                Next →
              </button>
            </div>
          )}
        </>
      )}
    </div>
  );
}

export default Home;
