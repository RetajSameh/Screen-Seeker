import { BrowserRouter, Routes, Route, Link, useLocation } from "react-router-dom";
import Home from "./pages/Home";
import Details from "./pages/Details";
import Watchlist from "./pages/Watchlist";
import { useWatchlist } from "./context/WatchlistContext";
import { useTheme } from "./context/ThemeContext";

function Navbar() {
  const { watchlist } = useWatchlist();
  const { theme, toggleTheme } = useTheme();
  const location = useLocation();

  return (
    <nav className="navbar">
      <Link to="/" className="brand">
        🎬 ScreenSeeker
      </Link>

      <ul className="navbar-links">
        <li>
          <Link to="/" className={location.pathname === "/" ? "active" : ""}>
            <span className="link-label">Discover</span>
          </Link>
        </li>
        <li>
          <Link
            to="/watchlist"
            className={location.pathname === "/watchlist" ? "active" : ""}
          >
            <span className="link-label">Watchlist</span>
            <span className="watchlist-count">{watchlist.length}</span>
          </Link>
        </li>
        <li>
          <button
            className="theme-toggle-btn"
            onClick={toggleTheme}
            aria-label={theme === "dark" ? "Switch to light mode" : "Switch to dark mode"}
          >
            {theme === "dark" ? "☀️ Light" : "🌙 Dark"}
          </button>
        </li>
      </ul>
    </nav>
  );
}

function App() {
  return (
    <BrowserRouter>
      <Navbar />
      <div className="sprocket-divider" aria-hidden="true" />

      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/details/:id" element={<Details />} />
        <Route path="/watchlist" element={<Watchlist />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
