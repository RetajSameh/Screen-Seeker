import { createContext, useContext, useEffect, useState } from "react";

const WatchlistContext = createContext();

export function WatchlistProvider({ children }) {
  const [watchlist, setWatchlist] = useState(() => {
    const savedWatchlist = localStorage.getItem("watchlist");
    return savedWatchlist ? JSON.parse(savedWatchlist) : [];
  });

  useEffect(() => {
    localStorage.setItem("watchlist", JSON.stringify(watchlist));
  }, [watchlist]);

  const addToWatchlist = (show) => {
    setWatchlist((currentList) => {
      if (currentList.some((item) => item.id === show.id)) {
        return currentList;
      }

      return [...currentList, show];
    });
  };

  const removeFromWatchlist = (showId) => {
  setWatchlist((currentList) =>
    currentList.filter((item) => item.id !== showId)
  );
};

const clearWatchlist = () => {
  setWatchlist([]);
};

const isInWatchlist = (showId) => {
  return watchlist.some((item) => item.id === showId);
};

  return (
    <WatchlistContext.Provider
      value={{
  watchlist,
  addToWatchlist,
  removeFromWatchlist,
  clearWatchlist,
  isInWatchlist,
}}
    >
      {children}
    </WatchlistContext.Provider>
  );
}

// eslint-disable-next-line react-refresh/only-export-components -- provider + hook are intentionally colocated
export function useWatchlist() {
  return useContext(WatchlistContext);
}