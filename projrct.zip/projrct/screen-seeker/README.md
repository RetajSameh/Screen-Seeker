# ScreenSeeker

A responsive Movie & TV Show Discovery App built with React + Vite, powered by the free [TVMaze API](https://www.tvmaze.com/api).

See `ScreenSeeker_Documentation_Report.docx` for the full project documentation report.

## Features
- Discovery home feed with poster, title, rating, and genres
- Live search (400ms debounced) with genre filter and rating sort
- Details page with synopsis, network/premiere/status info, and full cast
- Watchlist with localStorage persistence and a live navbar badge
- Loading skeletons and error banners with retry
- Dark/light theme toggle (bonus) and pagination (bonus)

## Run locally
\`\`\`bash
npm install
npm run dev      # start dev server
npm run build    # production build (outputs to dist/)
\`\`\`
