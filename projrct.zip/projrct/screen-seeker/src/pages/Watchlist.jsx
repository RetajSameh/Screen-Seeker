import { Link } from "react-router-dom";
import { useWatchlist } from "../context/WatchlistContext";
import ShowCard from "../components/ShowCard";

function Watchlist() {
  const {
    watchlist,
    removeFromWatchlist,
    clearWatchlist,
  } = useWatchlist();

  return (
    <div className="watchlist-page">
      <Link to="/" className="back-home-btn">
        ← Back to Home
      </Link>

      <div className="page-header">
        <h1>My Watchlist</h1>
        {watchlist.length > 0 && (
          <p className="watchlist-subtitle">
            {watchlist.length} {watchlist.length === 1 ? "show" : "shows"} saved
          </p>
        )}
      </div>

      {watchlist.length > 0 && (
        <button
          className="clear-watchlist-btn"
          onClick={clearWatchlist}
        >
          🗑️ Clear All
        </button>
      )}

      {watchlist.length === 0 ? (
        <div className="empty-state">
          <div className="empty-state-icon">🎬</div>

          <h2>Your watchlist is empty</h2>

          <p>
            You haven't added any shows yet.
            Start exploring and save your favorite shows here!
          </p>

          <Link to="/" className="explore-btn">
            Explore Shows
          </Link>
        </div>
      ) : (
        <div className="shows-grid">
          {watchlist.map((show) => (
            <div className="watchlist-item" key={show.id}>
              <ShowCard show={show} />

              <button
                className="remove-watchlist-btn"
                onClick={() => removeFromWatchlist(show.id)}
              >
                🗑️ Remove from Watchlist
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default Watchlist;
