import { Link } from "react-router-dom";
import { useWatchlist } from "../context/WatchlistContext";

function ShowCard({ show }) {
  const { addToWatchlist, removeFromWatchlist, isInWatchlist } = useWatchlist();
  const inWatchlist = isInWatchlist(show.id);

  const handleWatchlistClick = (event) => {
    // Card is wrapped in a <Link>; stop the click from also triggering navigation.
    event.preventDefault();
    event.stopPropagation();

    if (inWatchlist) {
      removeFromWatchlist(show.id);
    } else {
      addToWatchlist(show);
    }
  };

  return (
    <Link to={`/details/${show.id}`} className="show-card-link">
      <div className="show-card">
        <div className="poster-frame">
          <img
            src={
              show.image?.medium ||
              "https://via.placeholder.com/210x295"
            }
            alt={show.name}
            loading="lazy"
          />
          <span className="rating-chip">
            ⭐ {show.rating?.average || "N/A"}
          </span>

          <button
            type="button"
            className={`card-watchlist-btn${inWatchlist ? " in-watchlist" : ""}`}
            onClick={handleWatchlistClick}
            aria-label={
              inWatchlist ? `Remove ${show.name} from Watchlist` : `Add ${show.name} to Watchlist`
            }
            title={inWatchlist ? "Remove from Watchlist" : "Add to Watchlist"}
          >
            {inWatchlist ? "★" : "☆"}
          </button>
        </div>

        <h2>{show.name}</h2>

        <p className="genres">
          {show.genres?.length
            ? show.genres.join(", ")
            : "No genres available"}
        </p>
      </div>
    </Link>
  );
}

export default ShowCard;
