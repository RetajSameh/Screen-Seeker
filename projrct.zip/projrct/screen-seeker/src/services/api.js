const BASE_URL = "https://api.tvmaze.com";

export const getShows = async () => {
  const pages = Array.from({ length: 10 }, (_, index) => index);

  const responses = await Promise.all(
    pages.map((page) =>
      fetch(`${BASE_URL}/shows?page=${page}`)
    )
  );

  const validResponses = responses.filter(
    (response) => response.ok
  );

  const data = await Promise.all(
    validResponses.map((response) => response.json())
  );

  return data.flat();
};

export const getEpisodes = async (id) => {
  const response = await fetch(`${BASE_URL}/shows/${id}/episodes`);

  if (!response.ok) {
    throw new Error("Failed to fetch episodes");
  }

  return response.json();
};

export const searchShows = async (query) => {
  const response = await fetch(
    `${BASE_URL}/search/shows?q=${encodeURIComponent(query)}`
  );

  if (!response.ok) {
    throw new Error("Failed to search shows");
  }

  const data = await response.json();

  return data.map((item) => item.show);
};