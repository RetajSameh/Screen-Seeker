// Presentational error banner. Takes the existing retry handler as
// a prop — it does not implement its own retry/fetch logic.

function ErrorState({ message, onRetry, className = "error-state" }) {
  return (
    <div className={className}>
      <div className="error-icon" aria-hidden="true">
        ⚠️
      </div>
      <p>{message}</p>
      <button onClick={onRetry} type="button">
        Try Again
      </button>
    </div>
  );
}

export default ErrorState;
